package com.openAIDemo.openAiSpringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OpenAiSpringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(OpenAiSpringbootApplication.class, args);
	}

}
